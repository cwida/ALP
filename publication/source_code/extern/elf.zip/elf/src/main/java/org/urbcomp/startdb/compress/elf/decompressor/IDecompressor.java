package org.urbcomp.startdb.compress.elf.decompressor;

import java.util.List;

public interface IDecompressor {
    List<Double> decompress();
}
