package org.urbcomp.startdb.compress.elf.decompressor32;

import java.util.List;

public interface IDecompressor32 {
    List<Float> decompress();
}
